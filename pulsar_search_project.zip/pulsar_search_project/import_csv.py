import pandas as pd
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["pulsar_db"]
collection = db["observations"]

# Load and clean CSV
df = pd.read_csv("psr_database.csv")
df.rename(columns={
    'Source_name': 'source_name',
    'Epoch(MJD)': 'epoch_mjd',
    'Duration(sec)': 'duration_sec'
}, inplace=True)

# Drop old and insert fresh data
collection.drop()
collection.insert_many(df.to_dict(orient="records"))

print("✔ CSV data synced to MongoDB")
