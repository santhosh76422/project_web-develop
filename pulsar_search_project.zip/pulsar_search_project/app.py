from flask import Flask, request, render_template, send_file, jsonify
from pymongo import MongoClient
from bson import ObjectId
import csv
import io
import re

app = Flask(__name__)
client = MongoClient("mongodb://localhost:27017/")
collection = client["pulsar_db"]["observations"]

@app.route("/", methods=["GET", "POST"])
def index():
    results = []
    message = ""

    if request.method == "POST":
        source_name = request.form.get("source_name")
        epoch_start = request.form.get("epoch_start")
        epoch_end = request.form.get("epoch_end")
        duration_sec = request.form.get("duration_sec")

        if not (source_name or epoch_start or epoch_end or duration_sec):
            message = "At least one field must be filled."
            return render_template("index.html", results=[], message=message)

        query = {}

        # ✅ Handle comma-separated source names
        if source_name:
            names = [name.strip() for name in source_name.split(",") if name.strip()]
            if names:
                query["source_name"] = {"$in": names}

        if epoch_start or epoch_end:
            try:
                start = float(epoch_start) if epoch_start else 0
                end = float(epoch_end) if epoch_end else float('inf')
                query["epoch_mjd"] = {"$gte": start, "$lte": end}
            except ValueError:
                pass

        if duration_sec:
            try:
                query["duration_sec"] = {"$gte": float(duration_sec)}
            except ValueError:
                pass

        results = list(collection.find(query))

    return render_template("index.html", results=results, message=message)

@app.route("/suggest", methods=["GET"])
def suggest():
    query = request.args.get("q", "")
    if not query:
        return jsonify([])

    suggestions = collection.distinct("source_name", {
        "source_name": {"$regex": f"^{re.escape(query)}", "$options": "i"}
    })
    return jsonify(suggestions[:10])

@app.route("/download", methods=["POST"])
def download():
    selected_ids = request.json.get("selected_ids", [])
    object_ids = [ObjectId(id) for id in selected_ids]
    results = list(collection.find({"_id": {"$in": object_ids}}))

    if not results:
        return jsonify({"error": "No data found"}), 400

    output = io.StringIO()
    fieldnames = [key for key in results[0] if key != "_id"]
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    for row in results:
        writer.writerow({k: row.get(k, "") for k in fieldnames})

    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode()),
        mimetype="text/csv",
        as_attachment=True,
        download_name="selected_results.csv"
    )

if __name__ == "__main__":
    app.run(debug=True)
